package sensorcomp;

public interface ISensor {
  double takeNewReading();
  double lastReading();
}