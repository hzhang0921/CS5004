package chess;

/**
 * Enumeration to represent Black and White.
 */
public enum Color {
  BLACK, WHITE
}