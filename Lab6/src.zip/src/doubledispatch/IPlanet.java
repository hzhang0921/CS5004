package doubledispatch;

public interface IPlanet {
  void accept(ISpaceExplorer explorer);
}
