package registration;

public class Automobile extends AbstractVehicle {
  public Automobile(String make, int productionYear, double purchasePrice) {
    super(make, productionYear, purchasePrice, 5);
  }
}
