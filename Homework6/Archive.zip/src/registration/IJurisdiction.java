package registration;

public interface IJurisdiction {
  double exciseTax(IVehicle vehicle);
}