package registration;

public class Boat extends AbstractVehicle {
  public Boat(String make, int productionYear, double purchasePrice) {
    super(make, productionYear, purchasePrice, 10);
  }
}
