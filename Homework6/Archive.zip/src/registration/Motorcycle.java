package registration;

public class Motorcycle extends AbstractVehicle {
  public Motorcycle(String make, int productionYear, double purchasePrice) {
    super(make, productionYear, purchasePrice, 2);
  }
}
