package bank;

public class CheckingAccount extends Account{
  public CheckingAccount(double Balance) {
    super(Balance);
  }

  @Override
  public boolean withdraw(double Amount) {
    boolean result = super.withdraw(Amount);
    if (balance < 100) {
      feesDue += 5;
    }
    return result;
  }

}
