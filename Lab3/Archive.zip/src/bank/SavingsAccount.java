package bank;

public class SavingsAccount extends Account {
  public SavingsAccount(double Balance) {
    super(Balance);
  }

  @Override
  public void performMonthlyMaintenance() {
    if (NumOfTransactions > 6) {
      feesDue = 14;
      super.performMonthlyMaintenance();
    }
  }
}
