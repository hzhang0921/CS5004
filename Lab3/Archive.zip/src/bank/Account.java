package bank;

import java.awt.font.NumericShaper;

public abstract class Account implements IAccount{
  double balance;
  double feesDue;
  int NumOfTransactions;

  public Account(double starterAmount) {
      if (starterAmount < 0.01) {
        throw new IllegalArgumentException("Starter balance cannot be below $0.01");
      }
      NumOfTransactions = 0;
      feesDue = 0;
      this.balance = starterAmount;
  }

  public void deposit(double Amount) {
      if (Amount < 0) {
        throw new IllegalArgumentException("Deposit amount cannot be negative");
      }
      this.balance += Amount;
  }

  public boolean withdraw(double Amount) {
    if (Amount > this.balance || Amount < 0) {
      return false;
    }
    this.balance -= Amount;
    NumOfTransactions += 1;
    return true;
  }

  public double getBalance() {
    return this.balance;
  }

  public void performMonthlyMaintenance () {
    balance = balance - feesDue;
    NumOfTransactions = 0;
  }

  @Override
  public String toString() {
    return String.format("$%.2f", balance);
  }
}
